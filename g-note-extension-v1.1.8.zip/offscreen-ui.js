// Permission UI logic for offscreen.html when opened as a tab
const permissionUI = document.getElementById('permissionUI');
const requestBtn = document.getElementById('requestBtn');
const statusEl = document.getElementById('status');
const closeHint = document.getElementById('closeHint');

function showStatus(type, message) {
  statusEl.className = 'status ' + type;
  statusEl.textContent = message;
}

async function checkAndRequestPermission() {
  try {
    const result = await navigator.permissions.query({ name: 'microphone' });
    if (result.state === 'granted') {
      showStatus('success', '✓ Already enabled');
      closeHint.classList.remove('hidden');
      requestBtn.textContent = 'Done';
      requestBtn.disabled = true;
      
      // Notify extension and reset offscreen
      chrome.runtime.sendMessage({ type: 'mic-permission-granted' });
      chrome.runtime.sendMessage({ type: 'reset-offscreen' });
      
      setTimeout(() => window.close(), 1500);
      return;
    }
  } catch (e) {
    console.log('Permission query not supported');
  }
}

async function requestMicrophonePermission() {
  requestBtn.disabled = true;
  showStatus('pending', 'Requesting...');

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach(track => track.stop());
    
    showStatus('success', '✓ Microphone enabled');
    closeHint.classList.remove('hidden');
    requestBtn.textContent = 'Done';
    
    // Notify extension and reset offscreen document
    chrome.runtime.sendMessage({ type: 'mic-permission-granted' });
    chrome.runtime.sendMessage({ type: 'reset-offscreen' });
    
    setTimeout(() => window.close(), 2000);
    
  } catch (error) {
    console.error('Permission error:', error);
    requestBtn.disabled = false;
    
    if (error.name === 'NotAllowedError') {
      showStatus('error', 'Permission denied. Please try again.');
    } else if (error.name === 'NotFoundError') {
      showStatus('error', 'No microphone found.');
    } else {
      showStatus('error', 'Error: ' + error.message);
    }
  }
}

// Check if opened as a tab (not as offscreen document)
// Offscreen documents have very small viewport
const isOpenedAsTab = window.innerWidth > 100;

if (isOpenedAsTab && permissionUI) {
  requestBtn.addEventListener('click', requestMicrophonePermission);
  checkAndRequestPermission();
} else if (permissionUI) {
  // Hide UI when running as offscreen document
  permissionUI.classList.add('hidden');
}
