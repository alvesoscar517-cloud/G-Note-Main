// Permission priming script for microphone access

const requestBtn = document.getElementById('requestBtn')
const statusEl = document.getElementById('status')
const closeHint = document.getElementById('closeHint')

function showStatus(type, message) {
  statusEl.className = 'status ' + type
  statusEl.textContent = message
}

async function requestMicrophonePermission() {
  requestBtn.disabled = true
  showStatus('pending', 'Requesting...')

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    stream.getTracks().forEach(track => track.stop())
    
    showStatus('success', '✓ Microphone enabled')
    closeHint.style.display = 'block'
    requestBtn.textContent = 'Done'
    
    // Notify extension
    if (chrome.runtime) {
      chrome.runtime.sendMessage({ type: 'mic-permission-granted' })
    }
    
    // Store permission state
    localStorage.setItem('mic-permission-granted', 'true')
    
    // Close offscreen document to force recreation with new permission
    // This ensures the offscreen document picks up the new permission
    try {
      await chrome.runtime.sendMessage({ type: 'reset-offscreen' })
    } catch (e) {
      console.log('Could not reset offscreen:', e)
    }
    
    setTimeout(() => window.close(), 2000)
    
  } catch (error) {
    console.error('Permission error:', error)
    requestBtn.disabled = false
    
    if (error.name === 'NotAllowedError') {
      showStatus('error', 'Permission denied. Please try again.')
    } else if (error.name === 'NotFoundError') {
      showStatus('error', 'No microphone found.')
    } else {
      showStatus('error', 'Error: ' + error.message)
    }
  }
}

requestBtn.addEventListener('click', requestMicrophonePermission)

// Check existing permission
async function checkExistingPermission() {
  try {
    const result = await navigator.permissions.query({ name: 'microphone' })
    if (result.state === 'granted') {
      showStatus('success', '✓ Already enabled')
      closeHint.style.display = 'block'
      requestBtn.textContent = 'Done'
      requestBtn.disabled = true
      
      // Notify extension
      if (chrome.runtime) {
        chrome.runtime.sendMessage({ type: 'mic-permission-granted' })
      }
      
      localStorage.setItem('mic-permission-granted', 'true')
      setTimeout(() => window.close(), 1500)
    }
  } catch (e) {
    console.log('Permission query not supported')
  }
}

checkExistingPermission()
