// Offscreen document for Web Speech API
// This runs in a context where Web Speech API is available

let recognition = null
let isListening = false

// Check microphone permission status
async function checkMicPermission() {
  try {
    const result = await navigator.permissions.query({ name: 'microphone' })
    return result.state
  } catch (e) {
    return 'unknown'
  }
}

// Initialize speech recognition
function initRecognition(language) {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
  
  if (!SpeechRecognition) {
    chrome.runtime.sendMessage({
      type: 'speech-error',
      error: 'Speech recognition not supported'
    })
    return null
  }

  recognition = new SpeechRecognition()
  recognition.continuous = true
  recognition.interimResults = true
  recognition.lang = language || 'en-US'

  recognition.onstart = () => {
    isListening = true
    chrome.runtime.sendMessage({ type: 'speech-started' })
  }

  recognition.onend = () => {
    isListening = false
    chrome.runtime.sendMessage({ type: 'speech-ended' })
  }

  recognition.onerror = (event) => {
    console.error('[Offscreen] Speech error:', event.error)
    isListening = false
    chrome.runtime.sendMessage({
      type: 'speech-error',
      error: event.error
    })
  }

  recognition.onresult = (event) => {
    let interimTranscript = ''
    let finalTranscript = ''

    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript
      if (event.results[i].isFinal) {
        finalTranscript += transcript
      } else {
        interimTranscript += transcript
      }
    }

    chrome.runtime.sendMessage({
      type: 'speech-result',
      finalTranscript,
      interimTranscript
    })
  }

  return recognition
}

// Listen for messages from the extension
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target !== 'offscreen') return

  switch (message.type) {
    case 'start-speech':
      // Check permission first
      checkMicPermission().then(state => {
        console.log('[Offscreen] Mic permission state:', state)
        
        if (state === 'denied') {
          sendResponse({ success: false, error: 'not-allowed' })
          chrome.runtime.sendMessage({ type: 'speech-error', error: 'not-allowed' })
          return
        }
        
        if (!recognition || recognition.lang !== message.language) {
          recognition = initRecognition(message.language)
        }
        
        if (recognition && !isListening) {
          try {
            recognition.start()
            sendResponse({ success: true })
          } catch (err) {
            console.error('[Offscreen] Start error:', err)
            sendResponse({ success: false, error: err.message || 'not-allowed' })
          }
        } else {
          sendResponse({ success: false, error: 'Already listening or not initialized' })
        }
      })
      return true // Keep channel open for async

    case 'stop-speech':
      if (recognition && isListening) {
        recognition.stop()
      }
      sendResponse({ success: true })
      break

    case 'check-support':
      const supported = !!(window.SpeechRecognition || window.webkitSpeechRecognition)
      sendResponse({ supported })
      break

    case 'check-permission':
      checkMicPermission().then(state => {
        sendResponse({ state })
      })
      return true

    default:
      sendResponse({ error: 'Unknown message type' })
  }

  return true // Keep channel open for async response
})

// Notify that offscreen document is ready
chrome.runtime.sendMessage({ type: 'offscreen-ready' })
